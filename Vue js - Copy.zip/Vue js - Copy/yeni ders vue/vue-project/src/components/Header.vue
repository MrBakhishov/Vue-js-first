<script setup>

import NavbarVue from './Navbar.vue';

</script>


<template>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-6 mt-3">
                    Phone Number
                </div>
                <div class="col-6 d-flex justify-content-end mt-3">
                    Social network
                </div>
            </div>
        </div>


    <NavbarVue/>
    </div>
</template>