<script setup>

import cardVue from './card.vue';
</script>

<template>
    <div class="container">
        <h1 class="text-center">Home page</h1>



        <div class="row">
            <div v-for="item of 6 " :key="item" class="col-4 mt-5">
                <cardVue/>
              
            </div>
        </div>


    </div>
</template>