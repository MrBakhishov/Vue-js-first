
<script setup>


import HeaderVue from './components/Header.vue';
import HomeVue from './components/home/Home.vue';
</script>


<template>
  <div>
   <HeaderVue/>
   <HomeVue/>

  </div>
</template>



